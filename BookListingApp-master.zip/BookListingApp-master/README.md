# BookListingApp
This is Simple Book Listing App made with using Google Book's Api, And Layout Designing With Android.support Design Library Thanks to Androidhive.com    
       
Parcelable vs Serialization: https://www.3pillarglobal.com/insights/parcelable-vs-java-serialization-in-android-app-development?cn-reloaded=1     
      
Watch this video: https://www.youtube.com/watch?v=KEUT03DxQXE
